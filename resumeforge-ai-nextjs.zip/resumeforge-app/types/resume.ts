// STATUS: Implemented.
// Single source of truth for "what a resume looks like" on the client.
// Every one of the 12 templates renders THIS shape — switching templates
// never touches this data, only which component renders it.

export interface PersonalInfo {
  fullName: string;
  jobTitle: string;
  email: string;
  phone: string;
  location: string;
  linkedin?: string;
  github?: string;
  portfolio?: string;
}

export interface ExperienceItem {
  id: string;
  company: string;
  position: string;
  location?: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string; // newline-separated bullet lines
}

export interface EducationItem {
  id: string;
  institution: string;
  degree: string;
  field?: string;
  startDate: string;
  endDate: string;
  grade?: string;
}

export type SkillCategory = "Technical" | "Soft" | "Tools" | "Languages" | "Certifications";

export interface SkillItem {
  id: string;
  name: string;
  category: SkillCategory;
}

export interface ProjectItem {
  id: string;
  name: string;
  description: string;
  technologies?: string;
  url?: string;
  githubUrl?: string;
}

export interface ResumeData {
  id: string;
  title: string;
  templateId: string;
  personal: PersonalInfo;
  summary: string;
  experience: ExperienceItem[];
  education: EducationItem[];
  skills: SkillItem[];
  projects: ProjectItem[];
  atsScore?: number | null;
  jobMatchScore?: number | null;
}

export const EMPTY_RESUME: ResumeData = {
  id: "",
  title: "Untitled Resume",
  templateId: "modern",
  personal: { fullName: "", jobTitle: "", email: "", phone: "", location: "" },
  summary: "",
  experience: [],
  education: [],
  skills: [],
  projects: [],
};
