// STATUS: Implemented. isAuthenticated is resolved server-side from the
// real session (not a client guess) and passed down to client components
// that need it.
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/auth-options";
import { Navbar } from "@/components/landing/Navbar";
import { Hero } from "@/components/landing/Hero";
import { TemplateGallery } from "@/components/landing/TemplateGallery";
import { ATSShowcase } from "@/components/landing/ATSShowcase";
import { JobMatchShowcase } from "@/components/landing/JobMatchShowcase";
import { PricingSection } from "@/components/landing/PricingSection";
import { AIToolsSection } from "@/components/landing/AIToolsSection";
import { FinalCTA } from "@/components/landing/FinalCTA";

export default async function HomePage() {
  const session = await getServerSession(authOptions);
  const isAuthenticated = !!session?.user;

  return (
    <>
      <Navbar />
      <main>
        <Hero />

        <section id="ai-tools" className="px-6 py-28">
          <div className="mx-auto mb-14 max-w-2xl text-center">
            <div className="mb-3 text-[11px] uppercase tracking-wide text-champagne-dark">AI Resume Generation</div>
            <h2 className="font-display text-display-lg text-ink">From blank page to professional resume.</h2>
          </div>
          <AIToolsSection isAuthenticated={isAuthenticated} />
        </section>

        <section className="px-6 py-28">
          <div className="mx-auto mb-14 max-w-2xl text-center">
            <div className="mb-3 text-[11px] uppercase tracking-wide text-champagne-dark">Templates</div>
            <h2 className="font-display text-display-lg text-ink">12 templates, every one different.</h2>
            <p className="mt-4 text-muted">Three free, nine Pro — all ATS-conscious.</p>
          </div>
          <div className="mx-auto max-w-6xl">
            <TemplateGallery />
          </div>
        </section>

        <section className="px-6 py-28">
          <div className="mx-auto mb-14 max-w-2xl text-center">
            <div className="mb-3 text-[11px] uppercase tracking-wide text-champagne-dark">ATS Analysis</div>
            <h2 className="font-display text-display-lg text-ink">Know exactly how you'll parse.</h2>
          </div>
          <ATSShowcase />
        </section>

        <section className="px-6 py-28">
          <div className="mx-auto mb-14 max-w-2xl text-center">
            <div className="mb-3 text-[11px] uppercase tracking-wide text-champagne-dark">Job Match</div>
            <h2 className="font-display text-display-lg text-ink">Paste a job. See where you stand.</h2>
          </div>
          <JobMatchShowcase />
        </section>

        <section className="px-6 py-28">
          <div className="mx-auto mb-14 max-w-2xl text-center">
            <div className="mb-3 text-[11px] uppercase tracking-wide text-champagne-dark">Pricing</div>
            <h2 className="font-display text-display-lg text-ink">Start free. Upgrade when you need more.</h2>
          </div>
          <PricingSection />
        </section>

        <FinalCTA />
      </main>
    </>
  );
}
