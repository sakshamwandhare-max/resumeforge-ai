// STATUS: Implemented. Requires DATABASE_URL + auth session.
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { requireUserId, UnauthorizedError } from "@/lib/auth/session";

// GET /api/resume — list the current user's resumes only.
export async function GET() {
  try {
    const userId = await requireUserId();
    const resumes = await prisma.resume.findMany({
      where: { userId }, // <-- hard scope; never trust a client-supplied userId
      orderBy: { updatedAt: "desc" },
      select: {
        id: true,
        title: true,
        templateId: true,
        atsScore: true,
        jobMatchScore: true,
        updatedAt: true,
        fullName: true,
      },
    });
    return NextResponse.json({ resumes });
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return NextResponse.json({ error: "Please log in." }, { status: 401 });
    }
    console.error("[GET /api/resume]", err);
    return NextResponse.json({ error: "Something went wrong. Please try again." }, { status: 500 });
  }
}

// POST /api/resume — create a new blank resume for the current user.
export async function POST(req: NextRequest) {
  try {
    const userId = await requireUserId();

    // Enforce plan limits server-side (never trust the client's idea of its plan).
    const [user, resumeCount] = await Promise.all([
      prisma.user.findUniqueOrThrow({ where: { id: userId }, select: { plan: true } }),
      prisma.resume.count({ where: { userId } }),
    ]);
    const FREE_RESUME_LIMIT = 1;
    if (user.plan === "FREE" && resumeCount >= FREE_RESUME_LIMIT) {
      return NextResponse.json(
        { error: "Free plan is limited to 1 resume. Upgrade to Pro for unlimited resumes." },
        { status: 403 }
      );
    }

    const body = await req.json().catch(() => ({}));
    const title = typeof body?.title === "string" ? body.title.slice(0, 200) : "Untitled Resume";

    const resume = await prisma.resume.create({
      data: { userId, title },
      select: { id: true, title: true, templateId: true, updatedAt: true },
    });

    return NextResponse.json({ resume }, { status: 201 });
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return NextResponse.json({ error: "Please log in." }, { status: 401 });
    }
    console.error("[POST /api/resume]", err);
    return NextResponse.json({ error: "Something went wrong. Please try again." }, { status: 500 });
  }
}
