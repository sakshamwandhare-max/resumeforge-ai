// STATUS: Implemented. Requires DATABASE_URL + auth session.
//
// Ownership pattern used throughout: every query filters by
// `{ id: params.id, userId }` together, never `{ id: params.id }` alone.
// This is what "users must only access their own private resume data"
// means in practice — an authenticated user requesting someone else's
// resume id gets a 404, not their data (404 rather than 403 to avoid
// confirming the id exists at all).

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { requireUserId, UnauthorizedError } from "@/lib/auth/session";
import { updateResumeSchema } from "@/lib/validation/resume";

async function assertOwnership(resumeId: string, userId: string) {
  const resume = await prisma.resume.findFirst({ where: { id: resumeId, userId }, select: { id: true } });
  if (!resume) return false;
  return true;
}

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const resume = await prisma.resume.findFirst({
      where: { id: params.id, userId },
      include: {
        experiences: { orderBy: { sortOrder: "asc" } },
        educations: { orderBy: { sortOrder: "asc" } },
        skills: { orderBy: { sortOrder: "asc" } },
        projects: { orderBy: { sortOrder: "asc" } },
      },
    });
    if (!resume) return NextResponse.json({ error: "Resume not found." }, { status: 404 });
    return NextResponse.json({ resume });
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: "Please log in." }, { status: 401 });
    console.error("[GET /api/resume/:id]", err);
    return NextResponse.json({ error: "Something went wrong. Please try again." }, { status: 500 });
  }
}

// PATCH — autosave endpoint. Accepts a partial resume payload; replaces
// child collections (experiences/educations/skills/projects) atomically
// when provided, so client array edits (add/remove/reorder) stay simple.
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    if (!(await assertOwnership(params.id, userId))) {
      return NextResponse.json({ error: "Resume not found." }, { status: 404 });
    }

    const parsed = updateResumeSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0]?.message ?? "Invalid data" }, { status: 400 });
    }
    const input = parsed.data;

    const resume = await prisma.$transaction(async (tx) => {
      if (input.experiences) {
        await tx.experience.deleteMany({ where: { resumeId: params.id } });
        if (input.experiences.length) {
          await tx.experience.createMany({
            data: input.experiences.map((e, i) => ({ ...e, resumeId: params.id, sortOrder: i })),
          });
        }
      }
      if (input.educations) {
        await tx.education.deleteMany({ where: { resumeId: params.id } });
        if (input.educations.length) {
          await tx.education.createMany({
            data: input.educations.map((e, i) => ({ ...e, resumeId: params.id, sortOrder: i })),
          });
        }
      }
      if (input.skills) {
        await tx.skill.deleteMany({ where: { resumeId: params.id } });
        if (input.skills.length) {
          await tx.skill.createMany({
            data: input.skills.map((s, i) => ({ ...s, resumeId: params.id, sortOrder: i })),
          });
        }
      }
      if (input.projects) {
        await tx.project.deleteMany({ where: { resumeId: params.id } });
        if (input.projects.length) {
          await tx.project.createMany({
            data: input.projects.map((p, i) => ({ ...p, resumeId: params.id, sortOrder: i })),
          });
        }
      }

      return tx.resume.update({
        where: { id: params.id },
        data: {
          ...(input.title !== undefined ? { title: input.title } : {}),
          ...(input.templateId !== undefined ? { templateId: input.templateId } : {}),
          ...(input.summary !== undefined ? { summary: input.summary } : {}),
          ...(input.personal ?? {}),
        },
      });
    });

    return NextResponse.json({ resume, savedAt: new Date().toISOString() });
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: "Please log in." }, { status: 401 });
    console.error("[PATCH /api/resume/:id]", err);
    return NextResponse.json({ error: "Couldn't save your changes. Please try again." }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    if (!(await assertOwnership(params.id, userId))) {
      return NextResponse.json({ error: "Resume not found." }, { status: 404 });
    }
    // Cascade delete configured in schema.prisma removes children automatically.
    await prisma.resume.delete({ where: { id: params.id } });
    return NextResponse.json({ message: "Resume deleted." });
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: "Please log in." }, { status: 401 });
    console.error("[DELETE /api/resume/:id]", err);
    return NextResponse.json({ error: "Couldn't delete this resume. Please try again." }, { status: 500 });
  }
}
