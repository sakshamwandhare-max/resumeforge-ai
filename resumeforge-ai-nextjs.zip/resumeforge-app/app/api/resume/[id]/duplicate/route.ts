// STATUS: Implemented. Requires DATABASE_URL + auth session.
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { requireUserId, UnauthorizedError } from "@/lib/auth/session";

export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();

    const original = await prisma.resume.findFirst({
      where: { id: params.id, userId },
      include: { experiences: true, educations: true, skills: true, projects: true },
    });
    if (!original) return NextResponse.json({ error: "Resume not found." }, { status: 404 });

    const [user, resumeCount] = await Promise.all([
      prisma.user.findUniqueOrThrow({ where: { id: userId }, select: { plan: true } }),
      prisma.resume.count({ where: { userId } }),
    ]);
    if (user.plan === "FREE" && resumeCount >= 1) {
      return NextResponse.json(
        { error: "Free plan is limited to 1 resume. Upgrade to Pro for unlimited resumes." },
        { status: 403 }
      );
    }

    const copy = await prisma.resume.create({
      data: {
        userId,
        title: `${original.title} (copy)`,
        templateId: original.templateId,
        fullName: original.fullName,
        jobTitle: original.jobTitle,
        email: original.email,
        phone: original.phone,
        location: original.location,
        linkedin: original.linkedin,
        github: original.github,
        portfolio: original.portfolio,
        summary: original.summary,
        experiences: {
          create: original.experiences.map(({ id, resumeId, ...rest }) => rest),
        },
        educations: {
          create: original.educations.map(({ id, resumeId, ...rest }) => rest),
        },
        skills: {
          create: original.skills.map(({ id, resumeId, ...rest }) => rest),
        },
        projects: {
          create: original.projects.map(({ id, resumeId, ...rest }) => rest),
        },
      },
    });

    return NextResponse.json({ resume: copy }, { status: 201 });
  } catch (err) {
    if (err instanceof UnauthorizedError) return NextResponse.json({ error: "Please log in." }, { status: 401 });
    console.error("[POST /api/resume/:id/duplicate]", err);
    return NextResponse.json({ error: "Couldn't duplicate this resume. Please try again." }, { status: 500 });
  }
}
