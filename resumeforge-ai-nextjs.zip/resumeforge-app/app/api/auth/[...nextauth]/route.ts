// STATUS: Implemented. Requires AUTH_SECRET + DATABASE_URL.
import NextAuth from "next-auth";
import { authOptions } from "@/lib/auth/auth-options";

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
