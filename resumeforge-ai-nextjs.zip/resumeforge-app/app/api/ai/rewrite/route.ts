// STATUS: Implemented. Requires AI_API_KEY. Cost: 5 credits.
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { handleAIRequest } from "@/lib/ai/handle-ai-request";
import { generateText } from "@/lib/ai/client";
import { rewritePrompt } from "@/lib/ai/prompts";

const bodySchema = z.object({
  text: z.string().min(1).max(4000),
  style: z.enum(["Professional", "Concise", "Clear", "Formal"]),
});

export async function POST(req: NextRequest) {
  const parsed = bodySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  return handleAIRequest("rewrite", async () => {
    const text = await generateText(rewritePrompt(parsed.data), 400);
    return { text };
  });
}
