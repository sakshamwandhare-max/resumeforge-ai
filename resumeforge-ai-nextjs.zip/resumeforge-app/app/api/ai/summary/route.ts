// STATUS: Implemented. Requires AI_API_KEY. Cost: 5 credits (lib/ai/credits.ts).
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { handleAIRequest } from "@/lib/ai/handle-ai-request";
import { generateText } from "@/lib/ai/client";
import { summaryPrompt } from "@/lib/ai/prompts";

const bodySchema = z.object({
  jobTitle: z.string().max(200).optional(),
  experienceText: z.string().max(4000).default(""),
  skills: z.array(z.string().max(100)).max(50).default([]),
  careerGoal: z.string().max(500).optional(),
  variant: z.enum(["Professional", "Concise", "Executive", "Fresh Graduate"]).optional(),
});

export async function POST(req: NextRequest) {
  const parsed = bodySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  return handleAIRequest("summary", async () => {
    const text = await generateText(summaryPrompt(parsed.data), 200);
    return { summary: text };
  });
}
