// STATUS: Implemented. Requires AI_API_KEY. Cost: 20 credits.
// This is the endpoint behind "Make My Resume with AI" — it does not create
// or save a resume itself (that stays a deliberate user action via
// POST /api/resume + PATCH), it only returns structured content for the
// client to populate into the builder for the user to review and edit.
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { handleAIRequest } from "@/lib/ai/handle-ai-request";
import { generateText } from "@/lib/ai/client";
import { generateResumePrompt } from "@/lib/ai/prompts";

const bodySchema = z.object({
  name: z.string().min(1).max(200),
  targetJob: z.string().min(1).max(200),
  experienceText: z.string().max(4000),
  educationText: z.string().max(2000),
  skillsText: z.string().max(1000),
  projectsText: z.string().max(2000).optional().default(""),
  careerGoal: z.string().max(500).optional(),
  jobDescription: z.string().max(6000).optional(),
});

const outputSchema = z.object({
  summary: z.string(),
  experience: z
    .array(
      z.object({
        company: z.string(),
        position: z.string(),
        startDate: z.string().optional().default(""),
        endDate: z.string().optional().default(""),
        current: z.boolean().optional().default(false),
        description: z.string().optional().default(""),
      })
    )
    .default([]),
  education: z
    .array(
      z.object({
        institution: z.string(),
        degree: z.string().optional().default(""),
        startDate: z.string().optional().default(""),
        endDate: z.string().optional().default(""),
      })
    )
    .default([]),
  skills: z
    .array(
      z.object({
        name: z.string(),
        category: z.enum(["Technical", "Soft", "Tools", "Languages", "Certifications"]),
      })
    )
    .default([]),
  projects: z
    .array(
      z.object({
        name: z.string(),
        description: z.string().optional().default(""),
        technologies: z.string().optional().default(""),
      })
    )
    .default([]),
});

export async function POST(req: NextRequest) {
  const parsed = bodySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.errors[0]?.message ?? "Invalid request." }, { status: 400 });
  }

  return handleAIRequest("generate_resume", async () => {
    const raw = await generateText(generateResumePrompt(parsed.data), 1200);
    const cleaned = raw.replace(/```json|```/g, "").trim();

    let json: unknown;
    try {
      json = JSON.parse(cleaned);
    } catch {
      throw new Error("AI returned a response that could not be parsed as structured resume data.");
    }

    const output = outputSchema.safeParse(json);
    if (!output.success) {
      throw new Error("AI response did not match the expected resume structure.");
    }

    return output.data;
  });
}
