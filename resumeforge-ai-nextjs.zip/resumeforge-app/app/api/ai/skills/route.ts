// STATUS: Implemented. Requires AI_API_KEY. Cost: 5 credits.
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { handleAIRequest } from "@/lib/ai/handle-ai-request";
import { generateText } from "@/lib/ai/client";
import { suggestSkillsPrompt } from "@/lib/ai/prompts";

const bodySchema = z.object({
  jobTitle: z.string().max(200).optional(),
  experienceText: z.string().max(4000).default(""),
  existingSkills: z.array(z.string().max(100)).max(100).default([]),
});

export async function POST(req: NextRequest) {
  const parsed = bodySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  return handleAIRequest("skills", async () => {
    const raw = await generateText(suggestSkillsPrompt(parsed.data), 100);
    const suggestions = raw
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean)
      .filter((s) => !parsed.data.existingSkills.some((e) => e.toLowerCase() === s.toLowerCase()))
      .slice(0, 6);
    return { suggestions };
  });
}
