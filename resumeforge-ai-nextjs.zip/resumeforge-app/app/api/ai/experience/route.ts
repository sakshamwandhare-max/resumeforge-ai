// STATUS: Implemented. Requires AI_API_KEY. Cost: 5 credits.
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { handleAIRequest } from "@/lib/ai/handle-ai-request";
import { generateText } from "@/lib/ai/client";
import { improveExperiencePrompt } from "@/lib/ai/prompts";

const bodySchema = z.object({
  position: z.string().max(200),
  company: z.string().max(200),
  description: z.string().min(1, "Add a description before improving it.").max(4000),
});

export async function POST(req: NextRequest) {
  const parsed = bodySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.errors[0]?.message ?? "Invalid request." }, { status: 400 });
  }

  return handleAIRequest("experience", async () => {
    const text = await generateText(improveExperiencePrompt(parsed.data), 300);
    return { description: text };
  });
}
