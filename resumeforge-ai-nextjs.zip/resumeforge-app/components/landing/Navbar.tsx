// STATUS: Implemented. Uses next/link for real routes (no dead nav).
"use client";

import Link from "next/link";
import { useState } from "react";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/builder", label: "Builder" },
  { href: "/templates", label: "Templates" },
  { href: "/#ai-tools", label: "AI Tools" },
  { href: "/pricing", label: "Pricing" },
];

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b hairline-border bg-ivory/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="font-display text-lg tracking-tight text-ink">
          ResumeForge <span className="champagne-text">AI</span>
        </Link>

        <nav className="hidden items-center gap-8 text-sm text-ink/70 md:flex">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className="transition-colors hover:text-ink">
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <Link href="/login" className="text-sm text-ink/70 hover:text-ink">
            Log in
          </Link>
          <Link
            href="/signup"
            className="rounded-full bg-ink px-5 py-2.5 text-sm font-medium text-ivory transition-transform hover:-translate-y-0.5"
          >
            Get Started
          </Link>
        </div>

        <button
          aria-label="Toggle menu"
          aria-expanded={mobileOpen}
          className="flex flex-col gap-1.5 p-2 md:hidden"
          onClick={() => setMobileOpen((v) => !v)}
        >
          <span className="h-[1.5px] w-5 bg-ink" />
          <span className="h-[1.5px] w-5 bg-ink" />
          <span className="h-[1.5px] w-5 bg-ink" />
        </button>
      </div>

      {mobileOpen && (
        <div className="border-t hairline-border bg-ivory px-6 py-4 md:hidden">
          <nav className="flex flex-col gap-4 text-sm text-ink/80">
            {LINKS.map((l) => (
              <Link key={l.href} href={l.href} onClick={() => setMobileOpen(false)}>
                {l.label}
              </Link>
            ))}
            <div className="mt-2 flex gap-3 border-t hairline-border pt-4">
              <Link href="/login" className="text-ink/70">
                Log in
              </Link>
              <Link href="/signup" className="font-medium text-ink">
                Get Started
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
