// STATUS: Implemented.
"use client";

import { useState } from "react";
import { AIGenerateModal } from "./AIGenerateModal";

const PIPELINE = ["Your information", "AI analysis", "Content generation", "ATS optimization", "Professional resume"];

export function AIToolsSection({ isAuthenticated }: { isAuthenticated: boolean }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="mx-auto max-w-4xl">
      <div className="glass-panel flex flex-col items-center gap-8 p-10 md:p-14">
        <div className="flex flex-wrap items-center justify-center gap-3 text-[12px] text-muted">
          {PIPELINE.map((step, i) => (
            <div key={step} className="flex items-center gap-3">
              <span className="rounded-full border hairline-border bg-white px-3.5 py-1.5 text-ink/70">{step}</span>
              {i < PIPELINE.length - 1 && <span className="text-champagne">→</span>}
            </div>
          ))}
        </div>
        <button
          onClick={() => setOpen(true)}
          className="rounded-full bg-ink px-8 py-4 text-sm font-medium text-ivory transition-transform hover:-translate-y-0.5"
        >
          Make My Resume with AI
        </button>
        <p className="text-center text-[12.5px] text-muted">
          Never invents qualifications — every AI suggestion is built from what you provide, and you can edit
          everything before it's saved.
        </p>
      </div>

      <AIGenerateModal open={open} onClose={() => setOpen(false)} isAuthenticated={isAuthenticated} />
    </div>
  );
}
