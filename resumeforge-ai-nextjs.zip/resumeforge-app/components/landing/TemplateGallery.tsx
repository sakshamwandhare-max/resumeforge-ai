// STATUS: Implemented. Selecting a template on the public gallery stores
// the choice and routes into signup/builder — it does not silently do
// nothing. A logged-in-only "apply to my resume" version lives in
// components/builder/TemplatePicker.tsx (used inside the actual builder).
"use client";

import { useRouter } from "next/navigation";
import { TEMPLATES } from "@/lib/templates/registry";
import { SAMPLE_RESUME } from "@/lib/templates/sample-resume";
import { ResumeTemplateRenderer } from "@/components/resume/ResumeTemplateRenderer";

export function TemplateGallery() {
  const router = useRouter();

  function selectTemplate(templateId: string) {
    // Public visitors don't have a resume yet — carry the choice through
    // signup via a query param the signup flow reads and applies to the
    // first resume it creates (see app/signup/page.tsx).
    router.push(`/signup?template=${templateId}`);
  }

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {TEMPLATES.map((t) => (
        <button
          key={t.id}
          onClick={() => selectTemplate(t.id)}
          className="group text-left"
          aria-label={`Use the ${t.name} template`}
        >
          <div className="relative overflow-hidden rounded-2xl border hairline-border bg-white shadow-card transition-transform duration-200 group-hover:-translate-y-1.5">
            <div className="pointer-events-none h-64 origin-top scale-[0.42] overflow-hidden" style={{ width: "238%" }}>
              <ResumeTemplateRenderer data={{ ...SAMPLE_RESUME, templateId: t.id }} />
            </div>
            {t.tier === "pro" && (
              <span className="absolute right-3 top-3 rounded-full bg-champagne px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-white">
                Pro
              </span>
            )}
          </div>
          <div className="mt-3 flex items-center justify-between">
            <span className="font-display text-[15px] text-ink">{t.name}</span>
            <span className="text-[11px] uppercase tracking-wide text-muted">
              {t.tier === "free" ? "Free" : "Pro"}
            </span>
          </div>
        </button>
      ))}
    </div>
  );
}
