// STATUS: Implemented end-to-end (calls the real /api/ai/generate-resume
// route). Requires the user to be logged in (the API is credit-gated to an
// authenticated user) — if they're not logged in, submitting routes them to
// /signup first rather than silently failing, and their in-progress answers
// are preserved (see sessionStorage below) so they land back in this exact
// flow after creating an account.
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type Stage = "form" | "loading" | "error";

const LOADING_STEPS = [
  "Analyzing profile",
  "Understanding experience",
  "Writing content",
  "Optimizing keywords",
  "Building resume",
];

export interface GeneratedResumePayload {
  name: string;
  targetJob: string;
  experienceText: string;
  educationText: string;
  skillsText: string;
  projectsText: string;
  careerGoal: string;
  jobDescription: string;
}

interface AIGenerateModalProps {
  open: boolean;
  onClose: () => void;
  isAuthenticated: boolean;
}

export function AIGenerateModal({ open, onClose, isAuthenticated }: AIGenerateModalProps) {
  const router = useRouter();
  const [stage, setStage] = useState<Stage>("form");
  const [stepIndex, setStepIndex] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState<GeneratedResumePayload>({
    name: "",
    targetJob: "",
    experienceText: "",
    educationText: "",
    skillsText: "",
    projectsText: "",
    careerGoal: "",
    jobDescription: "",
  });

  if (!open) return null;

  function update<K extends keyof GeneratedResumePayload>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function submit() {
    if (!isAuthenticated) {
      // Preserve the filled-in form across the auth detour instead of
      // discarding it silently.
      sessionStorage.setItem("rf_pending_ai_generate", JSON.stringify(form));
      router.push("/signup?next=" + encodeURIComponent("/builder/new?generate=1"));
      return;
    }

    setStage("loading");
    setError(null);
    const stepTimer = setInterval(() => setStepIndex((i) => Math.min(i + 1, LOADING_STEPS.length - 1)), 900);

    try {
      const res = await fetch("/api/ai/generate-resume", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data?.error || "Something went wrong. Please try again.");
      }
      // Hand off to the builder, which reads this and lets the user review
      // and edit every field before anything is saved.
      sessionStorage.setItem("rf_generated_resume", JSON.stringify(data.result));
      router.push("/builder/new?generate=1");
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
      setStage("error");
    } finally {
      clearInterval(stepTimer);
    }
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-ink/30 p-4 backdrop-blur-sm">
      <div className="max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-4xl bg-white p-8 shadow-soft">
        <button onClick={onClose} className="float-right text-muted hover:text-ink" aria-label="Close">
          ✕
        </button>

        {stage === "form" && (
          <>
            <h2 className="font-display text-2xl text-ink">Your experience. AI-powered.</h2>
            <p className="mt-1 text-sm text-muted">
              Tell us about yourself — we'll structure it into a resume you can edit before anything is saved.
            </p>
            <div className="mt-6 flex flex-col gap-4">
              <Field label="Full name">
                <input className="input" value={form.name} onChange={(e) => update("name", e.target.value)} />
              </Field>
              <Field label="Target job title">
                <input className="input" value={form.targetJob} onChange={(e) => update("targetJob", e.target.value)} />
              </Field>
              <Field label="Experience">
                <textarea
                  className="input min-h-[100px]"
                  placeholder="Company, role, dates, what you did..."
                  value={form.experienceText}
                  onChange={(e) => update("experienceText", e.target.value)}
                />
              </Field>
              <Field label="Education">
                <textarea
                  className="input min-h-[70px]"
                  value={form.educationText}
                  onChange={(e) => update("educationText", e.target.value)}
                />
              </Field>
              <Field label="Skills">
                <input className="input" value={form.skillsText} onChange={(e) => update("skillsText", e.target.value)} />
              </Field>
              <Field label="Projects (optional)">
                <textarea
                  className="input min-h-[70px]"
                  value={form.projectsText}
                  onChange={(e) => update("projectsText", e.target.value)}
                />
              </Field>
              <Field label="Career goal (optional)">
                <input className="input" value={form.careerGoal} onChange={(e) => update("careerGoal", e.target.value)} />
              </Field>
              <Field label="Job description (optional — improves targeting)">
                <textarea
                  className="input min-h-[90px]"
                  value={form.jobDescription}
                  onChange={(e) => update("jobDescription", e.target.value)}
                />
              </Field>
            </div>
            <button
              onClick={submit}
              disabled={!form.name || !form.targetJob || !form.experienceText}
              className="mt-6 w-full rounded-full bg-ink py-3.5 text-sm font-medium text-ivory disabled:opacity-40"
            >
              Make My Resume with AI
            </button>
          </>
        )}

        {stage === "loading" && (
          <div className="flex flex-col items-center gap-6 py-10">
            <div className="h-10 w-10 animate-spin rounded-full border-2 border-champagne border-t-transparent" />
            <div className="flex flex-col items-center gap-2">
              {LOADING_STEPS.map((step, i) => (
                <div key={step} className={i === stepIndex ? "text-ink" : "text-muted/50"}>
                  {step}
                  {i === stepIndex ? "…" : ""}
                </div>
              ))}
            </div>
          </div>
        )}

        {stage === "error" && (
          <div className="flex flex-col items-center gap-4 py-10 text-center">
            <p className="text-ink">{error}</p>
            <button onClick={() => setStage("form")} className="rounded-full border hairline-border px-5 py-2 text-sm">
              Try again
            </button>
          </div>
        )}
      </div>

      <style jsx global>{`
        .input {
          width: 100%;
          border: 1px solid rgba(29, 29, 31, 0.1);
          border-radius: 0.75rem;
          padding: 0.65rem 0.85rem;
          font-size: 13.5px;
          background: white;
        }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-1.5 text-[12.5px] font-medium text-ink/70">
      {label}
      {children}
    </label>
  );
}
