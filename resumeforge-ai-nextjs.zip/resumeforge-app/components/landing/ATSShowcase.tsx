// STATUS: Implemented. Uses IntersectionObserver + requestAnimationFrame,
// no animation library dependency. On the marketing page this shows a
// representative sample score (92) — the real per-resume score comes from
// lib/ats/engine.ts and is shown inside the actual builder/ATS view.
"use client";

import { useEffect, useRef, useState } from "react";

const RADIUS = 88;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

const SUB_SCORES = [
  { label: "Keyword Match", value: 94 },
  { label: "Formatting", value: 96 },
  { label: "Skills", value: 89 },
  { label: "Readability", value: 93 },
];

export function ATSShowcase({ targetScore = 92 }: { targetScore?: number }) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(false);
  const [displayScore, setDisplayScore] = useState(0);

  useEffect(() => {
    const node = containerRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.4 }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!visible) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      setDisplayScore(targetScore);
      return;
    }
    let raf: number;
    const start = performance.now();
    const duration = 1400;
    function tick(now: number) {
      const progress = Math.min(1, (now - start) / duration);
      setDisplayScore(Math.round(progress * targetScore));
      if (progress < 1) raf = requestAnimationFrame(tick);
    }
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [visible, targetScore]);

  const offset = CIRCUMFERENCE - (displayScore / 100) * CIRCUMFERENCE;

  return (
    <div ref={containerRef} className="mx-auto flex max-w-4xl flex-col items-center gap-12 md:flex-row md:items-center">
      <div className="relative h-56 w-56 shrink-0">
        <svg width="224" height="224" viewBox="0 0 224 224" className="-rotate-90">
          <circle cx="112" cy="112" r={RADIUS} strokeWidth="14" fill="none" className="stroke-black/5" />
          <circle
            cx="112"
            cy="112"
            r={RADIUS}
            strokeWidth="14"
            fill="none"
            strokeLinecap="round"
            strokeDasharray={CIRCUMFERENCE}
            strokeDashoffset={offset}
            className="stroke-champagne transition-[stroke-dashoffset] duration-100 ease-linear"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display text-5xl text-ink">{displayScore}</span>
          <span className="text-[11px] uppercase tracking-wide text-muted">ATS Score</span>
        </div>
      </div>

      <div className="grid flex-1 grid-cols-2 gap-4">
        {SUB_SCORES.map((s) => (
          <div key={s.label} className="glass-card p-5">
            <div className="text-[11px] uppercase tracking-wide text-muted">{s.label}</div>
            <div className="font-display text-2xl text-ink">{visible ? s.value : 0}%</div>
          </div>
        ))}
      </div>
    </div>
  );
}
