// STATUS: Implemented. "Upgrade" buttons link to /pricing checkout flow
// (app/api/payments/checkout) — see PAYMENTS_README for what's implemented
// vs requires Stripe credentials.
import Link from "next/link";
import clsx from "clsx";

const PLANS = [
  {
    id: "free",
    name: "Free",
    price: "$0",
    features: ["3 templates", "Limited AI credits", "Basic ATS analysis", "PDF export"],
    cta: "Get Started",
    href: "/signup",
    featured: false,
  },
  {
    id: "pro",
    name: "Pro",
    price: "$12",
    features: ["All 12 templates", "Advanced AI credits", "Job optimization", "Advanced ATS analysis", "Unlimited resumes"],
    cta: "Go Pro",
    href: "/pricing?plan=pro",
    featured: true,
  },
  {
    id: "premium",
    name: "Premium",
    price: "$24",
    features: ["Everything in Pro", "Higher AI limits", "Priority processing", "Advanced career tools"],
    cta: "Get Premium",
    href: "/pricing?plan=premium",
    featured: false,
  },
];

export function PricingSection() {
  return (
    <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3">
      {PLANS.map((p) => (
        <div
          key={p.id}
          className={clsx(
            "flex flex-col rounded-4xl border p-8 transition-transform hover:-translate-y-1.5",
            p.featured ? "border-champagne bg-white shadow-soft" : "hairline-border bg-white/70 shadow-card"
          )}
        >
          <div className="text-[11px] uppercase tracking-wide text-muted">{p.name}</div>
          <div className="font-display mt-2 text-4xl text-ink">
            {p.price}
            <span className="text-sm font-sans text-muted">/mo</span>
          </div>
          <ul className="my-8 flex flex-1 flex-col gap-3">
            {p.features.map((f) => (
              <li key={f} className="flex items-start gap-2 text-[13px] text-ink/70">
                <span className="mt-0.5 text-champagne-dark">✓</span>
                {f}
              </li>
            ))}
          </ul>
          <Link
            href={p.href}
            className={clsx(
              "rounded-full px-6 py-3 text-center text-sm font-medium transition-transform hover:-translate-y-0.5",
              p.featured ? "bg-ink text-ivory" : "border hairline-border text-ink"
            )}
          >
            {p.cta}
          </Link>
        </div>
      ))}
    </div>
  );
}
