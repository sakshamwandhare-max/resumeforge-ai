// STATUS: Implemented (marketing showcase with representative sample data).
// The real, working job-match analysis against a user's actual resume and
// a pasted job description is the JobMatchPanel used inside the app
// (components/builder/JobMatchPanel.tsx), which calls POST /api/ai/job-match.
export function JobMatchShowcase() {
  const matched = ["React", "TypeScript", "Design Systems", "User Research"];
  const missing = ["Accessibility Audits", "A/B Testing"];

  return (
    <div className="mx-auto max-w-5xl">
      <div className="grid grid-cols-1 gap-6 md:grid-cols-[1fr_auto_1fr] md:items-center">
        <div className="glass-panel p-8">
          <div className="mb-3 text-[11px] uppercase tracking-wide text-muted">Job Description</div>
          <div className="space-y-2">
            <div className="h-2 w-full rounded bg-ink/10" />
            <div className="h-2 w-[92%] rounded bg-ink/10" />
            <div className="h-2 w-[80%] rounded bg-ink/10" />
            <div className="h-2 w-[85%] rounded bg-ink/10" />
          </div>
        </div>

        <div className="flex flex-col items-center justify-center">
          <div className="glass-card flex h-28 w-28 flex-col items-center justify-center rounded-full">
            <span className="font-display text-3xl text-ink">88%</span>
            <span className="text-[10px] uppercase tracking-wide text-muted">Job Match</span>
          </div>
        </div>

        <div className="glass-panel p-8">
          <div className="mb-3 text-[11px] uppercase tracking-wide text-muted">Your Resume</div>
          <div className="space-y-2">
            <div className="h-2 w-full rounded bg-ink/10" />
            <div className="h-2 w-[70%] rounded bg-ink/10" />
            <div className="h-2 w-[88%] rounded bg-ink/10" />
          </div>
        </div>
      </div>

      <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-3">
        <div>
          <div className="mb-3 text-[11px] uppercase tracking-wide text-muted">Matched Skills</div>
          <div className="flex flex-wrap gap-2">
            {matched.map((s) => (
              <span key={s} className="rounded-full bg-skyline-light px-3 py-1 text-[11px] text-ink/70">
                {s}
              </span>
            ))}
          </div>
        </div>
        <div>
          <div className="mb-3 text-[11px] uppercase tracking-wide text-muted">Missing Keywords</div>
          <div className="flex flex-wrap gap-2">
            {missing.map((s) => (
              <span key={s} className="rounded-full bg-champagne-light/40 px-3 py-1 text-[11px] text-champagne-dark">
                {s}
              </span>
            ))}
          </div>
        </div>
        <div>
          <div className="mb-3 text-[11px] uppercase tracking-wide text-muted">Recommended Improvement</div>
          <p className="text-[13px] leading-relaxed text-ink/70">
            Add a line referencing accessibility work if you have it — it's a recurring requirement in this
            role and currently missing from your resume.
          </p>
        </div>
      </div>
    </div>
  );
}
