// STATUS: Implemented.
import Link from "next/link";

export function FinalCTA() {
  return (
    <section className="relative overflow-hidden px-6 py-32 text-center">
      <div
        className="pointer-events-none absolute left-1/2 top-1/2 h-[420px] w-[320px] -translate-x-1/2 -translate-y-1/2 rotate-6 rounded-[28px] border border-white bg-white/60 opacity-40 blur-[1px]"
        aria-hidden
      />
      <div className="relative">
        <h2 className="font-display text-display-lg text-ink">
          Your next opportunity
          <br />
          starts with your resume.
        </h2>
        <Link
          href="/signup"
          className="mt-9 inline-block rounded-full bg-ink px-8 py-4 text-sm font-medium text-ivory transition-transform hover:-translate-y-0.5"
        >
          Create My Resume
        </Link>
      </div>
    </section>
  );
}
