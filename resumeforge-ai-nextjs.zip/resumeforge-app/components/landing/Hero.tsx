// STATUS: Implemented.
import Link from "next/link";
import { FloatingResumeHero } from "@/components/3d/FloatingResumeHero";

export function Hero() {
  return (
    <section className="relative overflow-hidden px-6 pb-24 pt-16 md:pb-32 md:pt-20">
      <div className="mx-auto max-w-6xl text-center">
        <h1 className="font-display text-hero text-ink">
          Build a resume
          <br />
          that <span className="champagne-text">gets noticed.</span>
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-muted">
          Create ATS-friendly resumes with AI-powered writing, intelligent job matching, and
          beautifully designed professional templates.
        </p>
        <div className="mt-9 flex flex-wrap items-center justify-center gap-4">
          <Link
            href="/signup"
            className="rounded-full bg-ink px-7 py-3.5 text-sm font-medium text-ivory transition-transform hover:-translate-y-0.5"
          >
            Create My Resume
          </Link>
          <Link
            href="/templates"
            className="rounded-full border hairline-border bg-white/70 px-7 py-3.5 text-sm font-medium text-ink backdrop-blur-sm transition-transform hover:-translate-y-0.5"
          >
            Explore Templates
          </Link>
        </div>
      </div>

      <div className="mx-auto mt-16 max-w-3xl">
        <FloatingResumeHero />
      </div>
    </section>
  );
}
