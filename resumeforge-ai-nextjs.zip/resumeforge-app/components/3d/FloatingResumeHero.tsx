// STATUS: Implemented.
//
// DESIGN NOTE: this uses CSS 3D transforms (perspective + rotateX/rotateY),
// not a WebGL/React Three Fiber scene. The brief allows either, and asks
// explicitly for restraint ("do not overdo the 3D", "performance is
// extremely important", "reduce on mobile"). A WebGL scene is heavier to
// load, harder to keep at 60fps on mid-range mobile, and — critically in
// this environment — impossible for me to verify renders correctly without
// a live browser (no network here to install three.js/R3F and no way to
// screenshot a canvas). CSS transforms are GPU-accelerated, degrade
// gracefully, and their correctness can actually be reasoned about from the
// code. If a true WebGL treatment is wanted later, this component is the
// single place to swap in a Three.js canvas — nothing else depends on the
// implementation, only on the layout slot it fills.

"use client";

import { useParallaxTilt } from "@/lib/hooks/use-parallax-tilt";
import { GlassStatCard } from "./GlassStatCard";

export function FloatingResumeHero() {
  const { ref, tilt } = useParallaxTilt<HTMLDivElement>(9);

  return (
    <div
      ref={ref}
      className="relative mx-auto h-[560px] w-full max-w-[560px]"
      style={{ perspective: "1600px" }}
    >
      {/* the physical "resume object" */}
      <div
        className="absolute left-1/2 top-1/2 h-[440px] w-[330px] -translate-x-1/2 -translate-y-1/2 rounded-[28px] border border-white bg-white/90 shadow-soft transition-transform duration-150 ease-out"
        style={{
          transform: `translate(-50%,-50%) rotateX(${8 + tilt.rotateX}deg) rotateY(${-10 + tilt.rotateY}deg)`,
          transformStyle: "preserve-3d",
        }}
      >
        <div className="p-8">
          <div className="mb-1 h-4 w-2/3 rounded bg-ink/85" />
          <div className="mb-6 h-2.5 w-1/3 rounded bg-champagne" />
          <div className="mb-2 h-2 w-full rounded bg-ink/10" />
          <div className="mb-2 h-2 w-[85%] rounded bg-ink/10" />
          <div className="mb-6 h-2 w-[70%] rounded bg-ink/10" />
          <div className="mb-2 h-2.5 w-1/4 rounded bg-ink/70" />
          <div className="mb-1.5 h-2 w-full rounded bg-ink/10" />
          <div className="mb-1.5 h-2 w-[90%] rounded bg-ink/10" />
          <div className="mb-6 h-2 w-[60%] rounded bg-ink/10" />
          <div className="flex flex-wrap gap-1.5">
            {["React", "Python", "SQL", "AWS"].map((s) => (
              <span key={s} className="rounded-full bg-skyline-light px-2.5 py-1 text-[10px] font-mono text-ink/70">
                {s}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* floating glass cards, at different translateZ depths for parallax feel */}
      <div
        className="absolute -right-2 top-4"
        style={{ transform: `translateZ(60px) rotateX(${tilt.rotateX * 0.6}deg) rotateY(${tilt.rotateY * 0.6}deg)` }}
      >
        <GlassStatCard label="ATS Score" value="92" />
      </div>

      <div
        className="absolute -left-6 bottom-16"
        style={{ transform: `translateZ(80px) rotateX(${tilt.rotateX * 0.6}deg) rotateY(${tilt.rotateY * 0.6}deg)` }}
      >
        <GlassStatCard label="Job Match" value="88%" />
      </div>

      <div
        className="absolute right-2 bottom-4"
        style={{ transform: `translateZ(40px) rotateX(${tilt.rotateX * 0.6}deg) rotateY(${tilt.rotateY * 0.6}deg)` }}
      >
        <GlassStatCard label="AI Improved" value="+12 pts" />
      </div>

      <div
        className="absolute left-1/2 -top-6 -translate-x-1/2"
        style={{ transform: `translateX(-50%) translateZ(100px)` }}
      >
        <div className="glass-card flex items-center gap-2 px-4 py-2 text-[11px] font-medium text-ink/70">
          <span className="h-2 w-2 rounded-full bg-champagne animate-count-pulse" />
          AI Generated
        </div>
      </div>
    </div>
  );
}
