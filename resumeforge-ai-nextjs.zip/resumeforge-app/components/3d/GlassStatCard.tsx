// STATUS: Implemented.
"use client";

import { ReactNode } from "react";
import clsx from "clsx";

interface GlassStatCardProps {
  label: string;
  value: ReactNode;
  className?: string;
  delayClass?: string; // stagger the floaty animation between cards
  icon?: ReactNode;
}

export function GlassStatCard({ label, value, className, delayClass, icon }: GlassStatCardProps) {
  return (
    <div
      className={clsx(
        "glass-card px-5 py-4 animate-floaty-slow select-none",
        delayClass,
        className
      )}
      style={{ animationDelay: delayClass ? undefined : "0s" }}
    >
      <div className="flex items-center gap-2 text-[11px] uppercase tracking-wide text-muted mb-1">
        {icon}
        {label}
      </div>
      <div className="font-display text-2xl text-ink">{value}</div>
    </div>
  );
}
