// STATUS: Implemented.
import clsx from "clsx";
import type { ResumeData } from "@/types/resume";
import { getTemplate, type SectionKey, type TemplateConfig } from "@/lib/templates/registry";

const DENSITY_GAP: Record<TemplateConfig["density"], string> = {
  compact: "gap-3",
  comfortable: "gap-5",
  spacious: "gap-7",
};
const DENSITY_PAD: Record<TemplateConfig["density"], string> = {
  compact: "p-6",
  comfortable: "p-10",
  spacious: "p-14",
};
const ACCENT_TEXT: Record<string, string> = {
  ink: "text-ink",
  champagne: "text-champagne-dark",
  skyline: "text-skyline",
  lavender: "text-[#8b7fae]",
  muted: "text-muted",
};
const ACCENT_BORDER: Record<string, string> = {
  ink: "border-ink/20",
  champagne: "border-champagne/40",
  skyline: "border-skyline/40",
  lavender: "border-lavender/50",
  muted: "border-muted/30",
};
const ACCENT_CHIP: Record<string, string> = {
  ink: "bg-ink/5 text-ink/70",
  champagne: "bg-champagne-light/40 text-champagne-dark",
  skyline: "bg-skyline-light text-ink/70",
  lavender: "bg-lavender-light text-ink/70",
  muted: "bg-black/5 text-muted",
};

function SectionHeading({ config, children }: { config: TemplateConfig; children: string }) {
  return (
    <h2
      className={clsx(
        "mb-2 text-[11px] font-semibold tracking-[0.08em]",
        ACCENT_TEXT[config.accent],
        config.uppercaseHeadings && "uppercase",
        config.dividers && clsx("border-b pb-1", ACCENT_BORDER[config.accent])
      )}
      style={config.headingFont === "display" ? { fontFamily: "var(--font-display)" } : undefined}
    >
      {children}
    </h2>
  );
}

function ExperienceBlock({ data, config }: { data: ResumeData; config: TemplateConfig }) {
  if (!data.experience.length) return null;
  return (
    <section>
      <SectionHeading config={config}>Experience</SectionHeading>
      <div className={clsx("flex flex-col", DENSITY_GAP[config.density])}>
        {data.experience.map((e) => (
          <div key={e.id}>
            <div className="flex items-baseline justify-between text-[13px] font-medium text-ink">
              <span>{e.position || "Role"}</span>
              <span className="text-[11px] font-normal text-muted">
                {e.startDate} – {e.current ? "Present" : e.endDate}
              </span>
            </div>
            <div className="text-[12px] text-muted">{e.company}</div>
            {e.description && (
              <ul className="mt-1 list-disc space-y-0.5 pl-4 text-[12.5px] leading-relaxed text-ink/80">
                {e.description
                  .split("\n")
                  .filter(Boolean)
                  .map((line, i) => (
                    <li key={i}>{line}</li>
                  ))}
              </ul>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

function EducationBlock({ data, config }: { data: ResumeData; config: TemplateConfig }) {
  if (!data.education.length) return null;
  return (
    <section>
      <SectionHeading config={config}>Education</SectionHeading>
      <div className={clsx("flex flex-col", DENSITY_GAP[config.density])}>
        {data.education.map((e) => (
          <div key={e.id}>
            <div className="flex items-baseline justify-between text-[13px] font-medium text-ink">
              <span>{e.degree || "Degree"}</span>
              <span className="text-[11px] font-normal text-muted">
                {e.startDate} – {e.endDate}
              </span>
            </div>
            <div className="text-[12px] text-muted">{e.institution}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function SkillsBlock({ data, config }: { data: ResumeData; config: TemplateConfig }) {
  if (!data.skills.length) return null;
  return (
    <section>
      <SectionHeading config={config}>Skills</SectionHeading>
      <div className="flex flex-wrap gap-1.5">
        {data.skills.map((s) => (
          <span key={s.id} className={clsx("rounded-full px-2.5 py-1 text-[10.5px]", ACCENT_CHIP[config.accent])}>
            {s.name}
          </span>
        ))}
      </div>
    </section>
  );
}

function ProjectsBlock({ data, config }: { data: ResumeData; config: TemplateConfig }) {
  if (!data.projects.length) return null;
  return (
    <section>
      <SectionHeading config={config}>Projects</SectionHeading>
      <div className={clsx("flex flex-col", DENSITY_GAP[config.density])}>
        {data.projects.map((p) => (
          <div key={p.id}>
            <div className="flex items-baseline justify-between text-[13px] font-medium text-ink">
              <span>{p.name}</span>
              {p.technologies && <span className="text-[11px] text-muted">{p.technologies}</span>}
            </div>
            {p.description && <p className="text-[12.5px] leading-relaxed text-ink/80">{p.description}</p>}
          </div>
        ))}
      </div>
    </section>
  );
}

function SummaryBlock({ data, config }: { data: ResumeData; config: TemplateConfig }) {
  if (!data.summary) return null;
  return (
    <section>
      <SectionHeading config={config}>Summary</SectionHeading>
      <p className="text-[12.5px] leading-relaxed text-ink/80">{data.summary}</p>
    </section>
  );
}

const SECTION_COMPONENTS: Record<SectionKey, typeof SummaryBlock> = {
  summary: SummaryBlock,
  experience: ExperienceBlock,
  education: EducationBlock,
  skills: SkillsBlock,
  projects: ProjectsBlock,
};

function Header({ data, config }: { data: ResumeData; config: TemplateConfig }) {
  return (
    <div className={clsx("mb-6", config.headerAlign === "center" && "text-center")}>
      <h1
        className="text-[22px] font-semibold text-ink"
        style={config.headingFont === "display" ? { fontFamily: "var(--font-display)" } : undefined}
      >
        {data.personal.fullName || "Your Name"}
      </h1>
      <div className={clsx("text-[13px]", ACCENT_TEXT[config.accent])}>{data.personal.jobTitle}</div>
      <div
        className={clsx(
          "mt-1.5 flex flex-wrap gap-x-3 gap-y-1 text-[10.5px] text-muted",
          config.headerAlign === "center" && "justify-center"
        )}
      >
        {[data.personal.email, data.personal.phone, data.personal.location, data.personal.linkedin]
          .filter(Boolean)
          .map((item, i) => (
            <span key={i}>{item}</span>
          ))}
      </div>
    </div>
  );
}

/**
 * Renders `data` using the layout described by the template config for
 * `templateId`. This is the ONLY place that decides DOM structure per
 * template — the builder, dashboard preview, and PDF export all call this
 * same function so the preview and export never drift apart.
 */
export function ResumeTemplateRenderer({ data }: { data: ResumeData }) {
  const config = getTemplate(data.templateId);
  const sections = config.sectionOrder.map((key) => {
    const Comp = SECTION_COMPONENTS[key];
    return <Comp key={key} data={data} config={config} />;
  });

  if (config.layout === "single") {
    return (
      <div className={clsx("bg-white", DENSITY_PAD[config.density])}>
        <Header data={data} config={config} />
        <div className={clsx("flex flex-col", DENSITY_GAP[config.density])}>{sections}</div>
      </div>
    );
  }

  // sidebar-left / sidebar-right: skills + education ride in the narrow
  // column, everything else in the main column — a genuinely different
  // reading order and visual weight than the single-column templates.
  const sidebarKeys: SectionKey[] = ["skills", "education"];
  const sidebarSections = config.sectionOrder
    .filter((k) => sidebarKeys.includes(k))
    .map((key) => {
      const Comp = SECTION_COMPONENTS[key];
      return <Comp key={key} data={data} config={config} />;
    });
  const mainSections = config.sectionOrder
    .filter((k) => !sidebarKeys.includes(k))
    .map((key) => {
      const Comp = SECTION_COMPONENTS[key];
      return <Comp key={key} data={data} config={config} />;
    });

  const sidebar = (
    <div className={clsx("flex w-[34%] flex-col bg-ivory/60", DENSITY_GAP[config.density], DENSITY_PAD[config.density])}>
      {sidebarSections}
    </div>
  );
  const main = (
    <div className={clsx("flex w-[66%] flex-col", DENSITY_GAP[config.density], DENSITY_PAD[config.density])}>
      <Header data={data} config={config} />
      {mainSections}
    </div>
  );

  return (
    <div className="flex bg-white">
      {config.layout === "sidebar-left" ? (
        <>
          {sidebar}
          {main}
        </>
      ) : (
        <>
          {main}
          {sidebar}
        </>
      )}
    </div>
  );
}
