// STATUS: Requires external configuration (EMAIL provider, e.g. Resend).
// Until RESEND_API_KEY (or an alternative provider) is set, these functions
// log to the server console instead of sending real email, so local/dev
// flows (e.g. password reset) remain testable without a mail account.
// This is intentionally NOT a fake success — callers get a real Promise
// that resolves once the log/send attempt completes.

import { Resend } from "resend";

const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;
const FROM = process.env.EMAIL_FROM || "ResumeForge AI <no-reply@resumeforge.example>";

async function send(to: string, subject: string, html: string) {
  if (!resend) {
    console.warn(
      `[lib/email] RESEND_API_KEY not set — email NOT sent. Would have sent to ${to}: "${subject}"\n${html}`
    );
    return { sent: false as const };
  }
  const result = await resend.emails.send({ from: FROM, to, subject, html });
  return { sent: true as const, id: result.data?.id };
}

export async function sendWelcomeEmail(to: string, name: string) {
  return send(to, "Welcome to ResumeForge AI", `<p>Hi ${name}, your account is ready.</p>`);
}

export async function sendPasswordResetEmail(to: string, resetUrl: string) {
  return send(
    to,
    "Reset your ResumeForge AI password",
    `<p>Click the link below to reset your password. This link expires in 30 minutes.</p><p><a href="${resetUrl}">${resetUrl}</a></p>`
  );
}

export async function sendSubscriptionConfirmationEmail(to: string, plan: string) {
  return send(to, "Subscription confirmed", `<p>You're now on the ${plan} plan.</p>`);
}

export async function sendPaymentFailedEmail(to: string) {
  return send(to, "Payment failed", `<p>Your recent payment didn't go through. Please update your payment method.</p>`);
}

export async function sendSubscriptionCanceledEmail(to: string) {
  return send(to, "Subscription canceled", `<p>Your subscription has been canceled and will end at the current period.</p>`);
}
