// STATUS: Implemented.
"use client";

import { useEffect, useRef, useState } from "react";

export interface ParallaxTilt {
  rotateX: number;
  rotateY: number;
}

/**
 * Tracks mouse position within `ref`'s bounding box and returns a subtle
 * rotation to apply via CSS transform. Returns a resting {0,0} tilt when the
 * user prefers reduced motion, or when the pointer leaves the element.
 */
export function useParallaxTilt<T extends HTMLElement>(maxDeg = 10) {
  const ref = useRef<T | null>(null);
  const [tilt, setTilt] = useState<ParallaxTilt>({ rotateX: 0, rotateY: 0 });
  const reducedMotionRef = useRef(false);

  useEffect(() => {
    reducedMotionRef.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }, []);

  useEffect(() => {
    const node = ref.current;
    if (!node || reducedMotionRef.current) return;

    function handleMove(e: MouseEvent) {
      const rect = node!.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      setTilt({ rotateY: x * maxDeg, rotateX: -y * maxDeg });
    }
    function handleLeave() {
      setTilt({ rotateX: 0, rotateY: 0 });
    }

    node.addEventListener("mousemove", handleMove);
    node.addEventListener("mouseleave", handleLeave);
    return () => {
      node.removeEventListener("mousemove", handleMove);
      node.removeEventListener("mouseleave", handleLeave);
    };
  }, [maxDeg]);

  return { ref, tilt };
}
