// STATUS: Implemented.
// Every field the client can send for a resume is validated here before it
// touches Prisma. userId is intentionally NOT a field on any of these
// schemas — it is always derived server-side from the session, never from
// the request body (see app/api/resume/* routes).

import { z } from "zod";

export const personalInfoSchema = z.object({
  fullName: z.string().trim().max(200).optional(),
  jobTitle: z.string().trim().max(200).optional(),
  email: z.string().trim().email().max(200).optional().or(z.literal("")),
  phone: z.string().trim().max(50).optional(),
  location: z.string().trim().max(200).optional(),
  linkedin: z.string().trim().max(300).optional(),
  github: z.string().trim().max(300).optional(),
  portfolio: z.string().trim().max(300).optional(),
});

export const experienceSchema = z.object({
  id: z.string().optional(), // present when updating an existing row
  company: z.string().trim().max(200),
  position: z.string().trim().max(200),
  location: z.string().trim().max(200).optional(),
  startDate: z.string().trim().max(50).optional(),
  endDate: z.string().trim().max(50).optional(),
  current: z.boolean().optional().default(false),
  description: z.string().trim().max(4000).optional(),
});

export const educationSchema = z.object({
  id: z.string().optional(),
  institution: z.string().trim().max(200),
  degree: z.string().trim().max(200).optional(),
  field: z.string().trim().max(200).optional(),
  startDate: z.string().trim().max(50).optional(),
  endDate: z.string().trim().max(50).optional(),
  grade: z.string().trim().max(50).optional(),
});

export const skillSchema = z.object({
  id: z.string().optional(),
  name: z.string().trim().min(1).max(100),
  category: z.enum(["Technical", "Soft", "Tools", "Languages", "Certifications"]),
});

export const projectSchema = z.object({
  id: z.string().optional(),
  name: z.string().trim().max(200),
  description: z.string().trim().max(2000).optional(),
  technologies: z.string().trim().max(300).optional(),
  url: z.string().trim().max(300).optional(),
  githubUrl: z.string().trim().max(300).optional(),
});

export const updateResumeSchema = z.object({
  title: z.string().trim().max(200).optional(),
  templateId: z.string().trim().max(50).optional(),
  personal: personalInfoSchema.optional(),
  summary: z.string().trim().max(2000).optional(),
  experiences: z.array(experienceSchema).max(30).optional(),
  educations: z.array(educationSchema).max(20).optional(),
  skills: z.array(skillSchema).max(100).optional(),
  projects: z.array(projectSchema).max(30).optional(),
});

export type UpdateResumeInput = z.infer<typeof updateResumeSchema>;
