// STATUS: Implemented. Pure function, no external dependency — runs
// deterministically against real resume data pulled from Postgres.
// This produces the numeric score and structural findings; the AI call in
// app/api/ats/[resumeId]/route.ts adds a short natural-language summary on
// top of these real findings (it does not invent the score itself).

import type { Resume, Experience, Education, Skill, Project } from "@prisma/client";

export type ResumeWithRelations = Resume & {
  experiences: Experience[];
  educations: Education[];
  skills: Skill[];
  projects: Project[];
};

export interface ATSResult {
  score: number;
  strengths: string[];
  improvements: string[];
  missingKeywords: string[];
}

const CORE_ATS_KEYWORDS = [
  "managed",
  "led",
  "developed",
  "built",
  "designed",
  "implemented",
  "improved",
  "collaborated",
  "analyzed",
  "delivered",
];

export function scoreResume(resume: ResumeWithRelations): ATSResult {
  let score = 30;
  const strengths: string[] = [];
  const improvements: string[] = [];
  const missingKeywords: string[] = [];

  // Contact completeness
  if (resume.fullName && resume.email && resume.phone) {
    score += 10;
    strengths.push("Contact information is complete");
  } else {
    improvements.push("Add your full name, email, and phone number");
  }

  // Summary
  if (resume.summary && resume.summary.trim().length >= 40) {
    score += 10;
    strengths.push("Professional summary is present and substantial");
  } else {
    improvements.push("Add a 2-3 sentence professional summary");
  }

  // Experience
  if (resume.experiences.length > 0) {
    score += 15;
    strengths.push(
      `${resume.experiences.length} experience ${resume.experiences.length === 1 ? "entry" : "entries"} listed`
    );
    const hasDates = resume.experiences.every((e) => e.startDate);
    if (!hasDates) improvements.push("Add start dates to every experience entry");
  } else {
    improvements.push("Add at least one experience entry");
  }

  // Education
  if (resume.educations.length > 0) {
    score += 8;
    strengths.push("Education section is complete");
  } else {
    improvements.push("Add your education background");
  }

  // Skills
  const skillCount = resume.skills.length;
  if (skillCount >= 5) {
    score += 12;
    strengths.push(`${skillCount} skills listed across categories`);
  } else {
    improvements.push("List at least 5 skills across categories");
    missingKeywords.push("Core technical skills");
  }

  // Measurable results (digits in experience descriptions)
  const hasMetrics = resume.experiences.some((e) => e.description && /\d/.test(e.description));
  if (hasMetrics) {
    score += 8;
    strengths.push("Some bullet points include measurable results");
  } else if (resume.experiences.length > 0) {
    improvements.push("Add measurable results to experience bullets where possible (e.g. percentages, counts)");
  }

  // Action-verb usage (real, deterministic keyword scan — not AI-guessed)
  const allDescriptions = resume.experiences.map((e) => (e.description ?? "").toLowerCase()).join(" ");
  const usedVerbs = CORE_ATS_KEYWORDS.filter((v) => allDescriptions.includes(v));
  if (usedVerbs.length >= 3) {
    score += 7;
    strengths.push("Uses strong action verbs consistently");
  } else {
    const missingVerbs = CORE_ATS_KEYWORDS.filter((v) => !usedVerbs.includes(v)).slice(0, 4);
    missingKeywords.push(...missingVerbs);
  }

  score = Math.max(0, Math.min(98, score));

  return { score, strengths, improvements, missingKeywords: missingKeywords.slice(0, 6) };
}
