// STATUS: Implemented.
// Central place every protected API route uses to resolve "who is calling".
// This is the ONLY source of truth for user identity server-side — the
// client never gets to assert its own userId (see lib/validation/*).

import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/auth-options";

export async function getCurrentUserId(): Promise<string | null> {
  const session = await getServerSession(authOptions);
  const id = (session?.user as { id?: string } | undefined)?.id;
  return id ?? null;
}

export class UnauthorizedError extends Error {
  constructor(message = "Unauthorized") {
    super(message);
    this.name = "UnauthorizedError";
  }
}

/** Throws if there's no authenticated user; otherwise returns their id. */
export async function requireUserId(): Promise<string> {
  const id = await getCurrentUserId();
  if (!id) throw new UnauthorizedError();
  return id;
}
