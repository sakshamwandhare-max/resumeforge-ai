// STATUS: Implemented.
//
// ARCHITECTURE NOTE: each template is a config, not a full duplicated
// component. The renderer (ResumeTemplateRenderer.tsx) reads `layout`
// (single-column vs sidebar, and sidebar side), `density`, `headerAlign`,
// `accent`, `headingFont`, and `sectionOrder` and produces genuinely
// different DOM structure and spacing per template — not just a palette
// swap. This keeps all 12 templates consistent with the shared ResumeData
// shape (switching template never touches content) while still being
// visually distinct. If a template later needs a structural feature no
// config captures (e.g. a photo circle), extend TemplateConfig — don't fork
// a new component file per template.

export type TemplateTier = "free" | "pro";
export type TemplateLayout = "single" | "sidebar-left" | "sidebar-right";
export type TemplateDensity = "compact" | "comfortable" | "spacious";
export type SectionKey = "summary" | "experience" | "education" | "skills" | "projects";

export interface TemplateConfig {
  id: string;
  name: string;
  tier: TemplateTier;
  layout: TemplateLayout;
  density: TemplateDensity;
  headerAlign: "left" | "center";
  accent: string; // tailwind color token, e.g. "champagne"
  headingFont: "display" | "sans"; // serif vs clean sans headings
  sectionOrder: SectionKey[];
  uppercaseHeadings: boolean;
  dividers: boolean;
}

const DEFAULT_ORDER: SectionKey[] = ["summary", "experience", "education", "skills", "projects"];

export const TEMPLATES: TemplateConfig[] = [
  {
    id: "classic",
    name: "Classic",
    tier: "free",
    layout: "single",
    density: "comfortable",
    headerAlign: "left",
    accent: "ink",
    headingFont: "display",
    sectionOrder: DEFAULT_ORDER,
    uppercaseHeadings: true,
    dividers: true,
  },
  {
    id: "minimal",
    name: "Minimal",
    tier: "free",
    layout: "single",
    density: "spacious",
    headerAlign: "left",
    accent: "muted",
    headingFont: "sans",
    sectionOrder: DEFAULT_ORDER,
    uppercaseHeadings: false,
    dividers: false,
  },
  {
    id: "modern",
    name: "Modern",
    tier: "free",
    layout: "sidebar-left",
    density: "comfortable",
    headerAlign: "left",
    accent: "champagne",
    headingFont: "sans",
    sectionOrder: ["summary", "experience", "projects", "education"],
    uppercaseHeadings: true,
    dividers: false,
  },
  {
    id: "executive",
    name: "Executive",
    tier: "pro",
    layout: "single",
    density: "comfortable",
    headerAlign: "center",
    accent: "ink",
    headingFont: "display",
    sectionOrder: ["summary", "experience", "education", "skills", "projects"],
    uppercaseHeadings: true,
    dividers: true,
  },
  {
    id: "tech",
    name: "Tech",
    tier: "pro",
    layout: "sidebar-right",
    density: "compact",
    headerAlign: "left",
    accent: "skyline",
    headingFont: "sans",
    sectionOrder: ["summary", "experience", "projects", "education"],
    uppercaseHeadings: true,
    dividers: false,
  },
  {
    id: "elegant",
    name: "Elegant",
    tier: "pro",
    layout: "single",
    density: "spacious",
    headerAlign: "center",
    accent: "champagne",
    headingFont: "display",
    sectionOrder: DEFAULT_ORDER,
    uppercaseHeadings: false,
    dividers: true,
  },
  {
    id: "corporate",
    name: "Corporate",
    tier: "pro",
    layout: "sidebar-left",
    density: "compact",
    headerAlign: "left",
    accent: "ink",
    headingFont: "sans",
    sectionOrder: ["summary", "experience", "education", "skills"],
    uppercaseHeadings: true,
    dividers: true,
  },
  {
    id: "creative",
    name: "Creative",
    tier: "pro",
    layout: "sidebar-right",
    density: "comfortable",
    headerAlign: "left",
    accent: "lavender",
    headingFont: "display",
    sectionOrder: ["summary", "projects", "experience", "education"],
    uppercaseHeadings: false,
    dividers: false,
  },
  {
    id: "compact",
    name: "Compact",
    tier: "pro",
    layout: "single",
    density: "compact",
    headerAlign: "left",
    accent: "muted",
    headingFont: "sans",
    sectionOrder: DEFAULT_ORDER,
    uppercaseHeadings: true,
    dividers: false,
  },
  {
    id: "graduate",
    name: "Graduate",
    tier: "pro",
    layout: "single",
    density: "comfortable",
    headerAlign: "left",
    accent: "skyline",
    headingFont: "display",
    sectionOrder: ["summary", "education", "projects", "experience", "skills"],
    uppercaseHeadings: false,
    dividers: true,
  },
  {
    id: "professional-plus",
    name: "Professional Plus",
    tier: "pro",
    layout: "sidebar-left",
    density: "comfortable",
    headerAlign: "left",
    accent: "champagne",
    headingFont: "display",
    sectionOrder: ["summary", "experience", "education", "skills", "projects"],
    uppercaseHeadings: true,
    dividers: true,
  },
  {
    id: "signature",
    name: "Signature",
    tier: "pro",
    layout: "single",
    density: "spacious",
    headerAlign: "center",
    accent: "champagne",
    headingFont: "display",
    sectionOrder: DEFAULT_ORDER,
    uppercaseHeadings: true,
    dividers: true,
  },
];

export function getTemplate(id: string): TemplateConfig {
  return TEMPLATES.find((t) => t.id === id) ?? TEMPLATES[0];
}
