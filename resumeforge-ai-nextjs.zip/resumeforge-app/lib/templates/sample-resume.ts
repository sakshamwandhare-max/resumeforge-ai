// STATUS: Implemented. Static placeholder content for previewing template
// layouts on the public site — never written to the database.
import type { ResumeData } from "@/types/resume";

export const SAMPLE_RESUME: ResumeData = {
  id: "sample",
  title: "Sample",
  templateId: "modern",
  personal: {
    fullName: "Jordan Lee",
    jobTitle: "Product Designer",
    email: "jordan@email.com",
    phone: "+1 555 0100",
    location: "Austin, TX",
    linkedin: "linkedin.com/in/jordanlee",
  },
  summary:
    "Product designer with 6 years building design systems and 0-to-1 features for B2B SaaS teams.",
  experience: [
    {
      id: "e1",
      company: "Northwind Software",
      position: "Senior Product Designer",
      startDate: "2022",
      endDate: "",
      current: true,
      description: "Led redesign of core dashboard, improving task completion by 24%\nBuilt and maintained a 40-component design system",
    },
    {
      id: "e2",
      company: "Fieldstone Labs",
      position: "Product Designer",
      startDate: "2019",
      endDate: "2022",
      current: false,
      description: "Shipped onboarding flow that cut support tickets by 18%",
    },
  ],
  education: [
    { id: "ed1", institution: "University of Texas", degree: "B.F.A. Design", startDate: "2015", endDate: "2019" },
  ],
  skills: [
    { id: "s1", name: "Figma", category: "Tools" },
    { id: "s2", name: "Design Systems", category: "Technical" },
    { id: "s3", name: "User Research", category: "Technical" },
    { id: "s4", name: "Prototyping", category: "Tools" },
  ],
  projects: [
    { id: "p1", name: "Design System v2", description: "Rebuilt component library across web and mobile.", technologies: "Figma, React" },
  ],
};
