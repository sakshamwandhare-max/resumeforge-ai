// STATUS: Implemented. Falls back to an in-memory limiter if
// UPSTASH_REDIS_REST_URL / UPSTASH_REDIS_REST_TOKEN are not set.
//
// IMPORTANT: the in-memory fallback only limits requests within a single
// server instance/process. On a multi-instance production deployment you
// MUST configure Upstash (or another shared store) — otherwise rate limits
// can be bypassed by hitting different instances.

import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

const hasUpstash = !!(process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN);

const upstashLimiter = hasUpstash
  ? new Ratelimit({
      redis: new Redis({
        url: process.env.UPSTASH_REDIS_REST_URL!,
        token: process.env.UPSTASH_REDIS_REST_TOKEN!,
      }),
      limiter: Ratelimit.slidingWindow(20, "1 m"),
      analytics: true,
      prefix: "rf:ratelimit",
    })
  : null;

// naive fallback: userId -> timestamps[]
const memoryStore = new Map<string, number[]>();
const WINDOW_MS = 60_000;
const MAX_IN_WINDOW = 20;

export async function checkRateLimit(key: string): Promise<{ success: boolean; remaining: number }> {
  if (upstashLimiter) {
    const result = await upstashLimiter.limit(key);
    return { success: result.success, remaining: result.remaining };
  }

  const now = Date.now();
  const timestamps = (memoryStore.get(key) ?? []).filter((t) => now - t < WINDOW_MS);
  if (timestamps.length >= MAX_IN_WINDOW) {
    memoryStore.set(key, timestamps);
    return { success: false, remaining: 0 };
  }
  timestamps.push(now);
  memoryStore.set(key, timestamps);
  return { success: true, remaining: MAX_IN_WINDOW - timestamps.length };
}
