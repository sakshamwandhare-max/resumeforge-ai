// STATUS: Implemented. Requires DATABASE_URL (writes go through Prisma).
//
// Credit costs are defined ONLY here, server-side. The client never sends
// a credit amount — it only names a feature, and the server looks up the
// cost. This is what prevents "credit manipulation" from the frontend.

export const CREDIT_COSTS = {
  summary: 5,
  experience: 5,
  project: 5,
  skills: 5,
  rewrite: 5,
  ats: 10,
  job_match: 15,
  generate_resume: 20,
} as const;

export type AIFeature = keyof typeof CREDIT_COSTS;

import { prisma } from "@/lib/db/prisma";

export class InsufficientCreditsError extends Error {
  constructor() {
    super("You don't have enough credits. Upgrade your plan to continue.");
    this.name = "InsufficientCreditsError";
  }
}

/**
 * Atomically checks and deducts credits for a feature BEFORE the AI call is
 * made, inside a single DB transaction with a row-level guard, so two
 * concurrent requests from the same user can't both pass a stale balance
 * check (no lost-update race).
 *
 * Returns the credit ledger row id — pass it to `refundCredits` if the AI
 * call subsequently fails, so the user is never charged for a failure.
 */
export async function reserveCredits(userId: string, feature: AIFeature) {
  const cost = CREDIT_COSTS[feature];

  return prisma.$transaction(async (tx) => {
    const user = await tx.user.findUniqueOrThrow({ where: { id: userId } });
    if (user.credits < cost) {
      throw new InsufficientCreditsError();
    }

    await tx.user.update({
      where: { id: userId },
      data: { credits: { decrement: cost } },
    });

    const usage = await tx.aIUsage.create({
      data: { userId, feature, creditsUsed: cost, success: false }, // flipped true on completion
    });

    return { usageId: usage.id, cost };
  });
}

/** Call when the AI request succeeds — marks the ledger entry as successful. */
export async function markCreditsSuccessful(usageId: string) {
  await prisma.aIUsage.update({
    where: { id: usageId },
    data: { success: true },
  });
}

/**
 * Call when the AI request fails AFTER credits were reserved — refunds the
 * credits and records the failure reason. Guarantees "never deduct credits
 * when the AI request fails".
 */
export async function refundCredits(userId: string, usageId: string, cost: number, errorMessage: string) {
  await prisma.$transaction([
    prisma.user.update({
      where: { id: userId },
      data: { credits: { increment: cost } },
    }),
    prisma.aIUsage.update({
      where: { id: usageId },
      data: { success: false, errorMessage: errorMessage.slice(0, 500) },
    }),
  ]);
}
