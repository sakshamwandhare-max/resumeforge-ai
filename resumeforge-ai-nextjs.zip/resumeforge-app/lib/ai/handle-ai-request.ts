// STATUS: Implemented. Requires DATABASE_URL + AI_API_KEY to actually
// generate text; without AI_API_KEY this correctly returns a 503 with a
// friendly message rather than fake output.

import { NextResponse } from "next/server";
import { requireUserId, UnauthorizedError } from "@/lib/auth/session";
import { checkRateLimit } from "@/lib/ai/rate-limit";
import { reserveCredits, markCreditsSuccessful, refundCredits, InsufficientCreditsError, type AIFeature } from "@/lib/ai/credits";
import { AIProviderError, AIUnavailableError } from "@/lib/ai/client";
import { prisma } from "@/lib/db/prisma";

/**
 * Wraps every /api/ai/* route with the same contract:
 *  1. must be authenticated
 *  2. must not be rate-limited
 *  3. must have enough credits (reserved BEFORE the AI call)
 *  4. on success: credits stay deducted, usage marked successful
 *  5. on any failure: credits are refunded, usage marked failed
 * `run` receives the authenticated userId and returns the JSON-able result.
 */
export async function handleAIRequest<T>(
  feature: AIFeature,
  run: (userId: string) => Promise<T>
): Promise<NextResponse> {
  let userId: string;
  try {
    userId = await requireUserId();
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return NextResponse.json({ error: "Please log in." }, { status: 401 });
    }
    throw err;
  }

  const { success } = await checkRateLimit(`ai:${userId}`);
  if (!success) {
    return NextResponse.json({ error: "Too many requests. Please slow down." }, { status: 429 });
  }

  let reservation: { usageId: string; cost: number };
  try {
    reservation = await reserveCredits(userId, feature);
  } catch (err) {
    if (err instanceof InsufficientCreditsError) {
      return NextResponse.json({ error: err.message }, { status: 402 });
    }
    console.error("[handleAIRequest] credit reservation failed", err);
    return NextResponse.json({ error: "Something went wrong. Please try again." }, { status: 500 });
  }

  try {
    const result = await run(userId);
    await markCreditsSuccessful(reservation.usageId);
    return NextResponse.json({ result, creditsUsed: reservation.cost });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    await refundCredits(userId, reservation.usageId, reservation.cost, message).catch((refundErr) =>
      console.error("[handleAIRequest] refund failed — needs manual reconciliation", { userId, reservation, refundErr })
    );

    if (err instanceof AIUnavailableError) {
      return NextResponse.json({ error: "AI is not configured yet. Please contact support." }, { status: 503 });
    }
    if (err instanceof AIProviderError) {
      console.error("[handleAIRequest] AI provider error", err);
      return NextResponse.json({ error: "AI is temporarily unavailable. Please try again shortly." }, { status: 502 });
    }
    console.error("[handleAIRequest] unexpected error", err);
    return NextResponse.json({ error: "Something went wrong. Please try again." }, { status: 500 });
  }
}

/** Ownership check reused by AI routes that operate on a specific resume. */
export async function assertResumeOwnership(resumeId: string, userId: string) {
  const resume = await prisma.resume.findFirst({ where: { id: resumeId, userId } });
  return resume;
}
