// STATUS: Implemented.
// Every prompt that touches user resume content repeats the same
// non-fabrication constraint. Centralizing it here means every AI route
// inherits the rule instead of each route author having to remember it.

const NO_FABRICATION_RULE =
  "Do not invent employers, job titles, dates, metrics, technologies, or skills that are not implied by the information given. If the input is too thin to improve meaningfully, say so instead of inventing content.";

export function summaryPrompt(input: {
  jobTitle?: string;
  experienceText: string;
  skills: string[];
  careerGoal?: string;
  variant?: "Professional" | "Concise" | "Executive" | "Fresh Graduate";
}) {
  return `Write a ${input.variant ?? "Professional"} resume summary (2-3 sentences, under 60 words) for this person.
${NO_FABRICATION_RULE}
Return ONLY the summary text — no preamble, no quotes.

Job title: ${input.jobTitle || "N/A"}
Experience: ${input.experienceText || "N/A"}
Skills: ${input.skills.join(", ") || "N/A"}
Career goal: ${input.careerGoal || "N/A"}`;
}

export function improveExperiencePrompt(input: { position: string; company: string; description: string }) {
  return `Rewrite this resume experience entry into 2-4 concise, achievement-oriented bullet points, one per line, no bullet symbols or numbering.
${NO_FABRICATION_RULE} Use measurable impact ONLY if implied by the input.
Return ONLY the rewritten lines.

Role: ${input.position} at ${input.company}
Original: ${input.description}`;
}

export function improveProjectPrompt(input: { name: string; technologies?: string; description: string }) {
  return `Rewrite this project description into one concise, ATS-friendly resume line (max 30 words).
${NO_FABRICATION_RULE}
Return ONLY the rewritten line.

Project: ${input.name}
Technologies: ${input.technologies || "N/A"}
Original: ${input.description}`;
}

export function suggestSkillsPrompt(input: { jobTitle?: string; experienceText: string; existingSkills: string[] }) {
  return `Based on this person's title and experience, suggest up to 6 relevant technical/tool skills they plausibly have but have not listed.
${NO_FABRICATION_RULE} Only suggest skills strongly implied by the experience given — do not guess generically.
Return ONLY a comma-separated list, nothing else.

Title: ${input.jobTitle || "N/A"}
Experience: ${input.experienceText || "N/A"}
Existing skills: ${input.existingSkills.join(", ") || "none"}`;
}

export function rewritePrompt(input: { text: string; style: "Professional" | "Concise" | "Clear" | "Formal" }) {
  return `Rewrite the following resume text in a ${input.style} style, preserving all factual content exactly.
${NO_FABRICATION_RULE}
Return ONLY the rewritten text.

Text: ${input.text}`;
}

export function generateResumePrompt(input: {
  name: string;
  targetJob: string;
  experienceText: string;
  educationText: string;
  skillsText: string;
  projectsText: string;
  careerGoal?: string;
  jobDescription?: string;
}) {
  return `You are helping structure a resume from information the person has provided about themselves. Return ONLY valid JSON (no markdown fences) in exactly this shape:
{"summary": "<2-3 sentence professional summary, under 60 words>", "experience": [{"company": "<string>", "position": "<string>", "startDate": "<string>", "endDate": "<string>", "current": <boolean>, "description": "<2-4 bullet lines separated by \\n>"}], "education": [{"institution": "<string>", "degree": "<string>", "startDate": "<string>", "endDate": "<string>"}], "skills": [{"name": "<string>", "category": "Technical|Soft|Tools|Languages|Certifications"}], "projects": [{"name": "<string>", "description": "<string>", "technologies": "<string>"}]}

${NO_FABRICATION_RULE} Only structure and lightly polish what is given — every company, date, degree, and skill in your output must come from the input below. If a field isn't provided, omit that entry rather than inventing one.
${input.jobDescription ? "Where natural, lean the summary and bullet phrasing toward this target job description, without adding skills or experience the person didn't state." : ""}

Name: ${input.name}
Target job: ${input.targetJob}
Career goal: ${input.careerGoal || "N/A"}
Experience (as described by the user): ${input.experienceText}
Education (as described by the user): ${input.educationText}
Skills (as described by the user): ${input.skillsText}
Projects (as described by the user): ${input.projectsText}
${input.jobDescription ? `Target job description: ${input.jobDescription}` : ""}`;
}

export function jobMatchPrompt(input: { resumeText: string; jobDescription: string }) {
  return `Compare this resume against the job description and return ONLY valid JSON (no markdown fences) in exactly this shape:
{"match_percent": <integer 0-100>, "matching_skills": [<up to 6 strings>], "missing_skills": [<up to 6 strings>], "recommended_keywords": [<up to 5 strings>], "suggested_summary_line": "<one sentence>", "sections_to_improve": [<up to 4 strings>]}
${NO_FABRICATION_RULE} "missing_skills" must reflect real gaps versus the job description, not fabricated resume content.

RESUME:
${input.resumeText}

JOB DESCRIPTION:
${input.jobDescription}`;
}
