// STATUS: Implemented, provider-agnostic. Requires AI_API_KEY.
//
// This file is imported ONLY by server-side code (app/api/ai/*, which run
// in the Node runtime, never in "use client" components). The API key is
// read from process.env here and never serialized into any response sent
// to the browser. Swapping providers means editing this file only —
// nothing above lib/ai/ needs to know which provider is in use.

const AI_API_KEY = process.env.AI_API_KEY;
const AI_MODEL = process.env.AI_MODEL || "claude-sonnet-4-6";

if (!AI_API_KEY && process.env.NODE_ENV === "production") {
  // Fail loudly at boot rather than silently returning empty AI output.
  console.error("[lib/ai/client] AI_API_KEY is not set — AI routes will return 503.");
}

export class AIProviderError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
    this.name = "AIProviderError";
  }
}

export class AIUnavailableError extends AIProviderError {
  constructor() {
    super("AI provider is not configured (missing AI_API_KEY)");
  }
}

/**
 * Calls the model with a single user-turn prompt and returns the raw text.
 * Throws AIProviderError (never leaks provider-internal details to callers
 * outside lib/ai — API routes turn this into a generic user-facing message).
 */
export async function generateText(prompt: string, maxTokens = 500): Promise<string> {
  if (!AI_API_KEY) throw new AIUnavailableError();

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20_000);

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": AI_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: AI_MODEL,
        max_tokens: maxTokens,
        messages: [{ role: "user", content: prompt }],
      }),
      signal: controller.signal,
    });

    if (res.status === 429) {
      throw new AIProviderError("Rate limited by AI provider", 429);
    }
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new AIProviderError(`AI provider error (${res.status}): ${body.slice(0, 300)}`, res.status);
    }

    const data = await res.json();
    const textBlock = (data.content as Array<{ type: string; text?: string }> | undefined)?.find(
      (b) => b.type === "text"
    );
    const text = textBlock?.text?.trim();
    if (!text) throw new AIProviderError("AI provider returned an empty response");
    return text;
  } catch (err) {
    if (err instanceof AIProviderError) throw err;
    if (err instanceof Error && err.name === "AbortError") {
      throw new AIProviderError("AI provider request timed out");
    }
    throw new AIProviderError(err instanceof Error ? err.message : "Unknown AI provider error");
  } finally {
    clearTimeout(timeout);
  }
}
